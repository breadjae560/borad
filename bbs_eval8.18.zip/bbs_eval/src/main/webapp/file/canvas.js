const saveBtn = document.getElementById("save");
const fileInput = document.getElementById("file");
const color = document.getElementById("color");
const lineWidth = document.getElementById("line-width");
const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 800;
ctx.lineWidth = lineWidth.value;

let isPainting = false;

function onMove(event) {
    if(isPainting){
        ctx.lineTo(event.offsetX, event.offsetY);
        ctx.stroke();
        return;
    }
    ctx.beginPath();
    ctx.moveTo(event.offsetX, event.offsetY);
}

function onMouseDown() {
    isPainting = true;
}

function cancelPaint() {
    isPainting = false;
}

function onLineWidthChange(event) {
    ctx.lineWidth = event.target.value;
}

function onColorChange(event) {
    ctx.strokeStyle = event.target.value;
    ctx.fillStyle = event.target.value;
}

function onFileChange(event) {
    const file = event.target.files[0];
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.src = url;
    image.onload = function() {
        ctx.drawImage(image, 400, 400, canvas.width/5, canvas.height/5);
        fileInput.value = null;
    }
}

function onSaveClick() {
    const url = canvas.toDataURL();
    const a = document.createElement("a")
    a.href = url;
    a.download = "text.png";
    a.click();
}


canvas.addEventListener("mousemove", onMove);
canvas.addEventListener("mousedown", onMouseDown);
canvas.addEventListener("mouseup", cancelPaint);
canvas.addEventListener("mouseleave", cancelPaint);

lineWidth.addEventListener("change", onLineWidthChange);
color.addEventListener("change", onColorChange);
fileInput.addEventListener("change", onFileChange);
saveBtn.addEventListener("click", onSaveClick);