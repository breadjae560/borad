야간 모드 구동 되는지 확인 

icon, iconDetail 확인 

메인 확인 

캔버스 확인

-- file --> icon --> 메인 --> 야간 