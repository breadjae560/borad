const convas = document.querySelector("canvas");
const ctx = convas.getContext("2d");

canvas.width = 1000;
canvas.height = 800;



