package com.DTO;

import lombok.Data;

@Data
public class User_CommentDTO {
	String list_Num;
	String comment_num;
	String nicName;
	String post_comment;
	String time;
}
