package com.Servlets;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.Dao;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;


@WebServlet("/listWriteServlet")
public class listWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");

		MultipartRequest multi = new MultipartRequest(request, request.getSession().getServletContext().getRealPath("/files"), // 파일을 저장할 경로
				20 * 1024 * 1024, // 최대 파일 크기 (20MB)
				"utf-8", // 인코딩
				new DefaultFileRenamePolicy() // 동일 파일명 처리 방법
		);

		File file = multi.getFile("upload"); // 파일 객체 얻기

	
		if (file != null) {
			
			try {
			Class.forName("org.mariadb.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/green", "root", "1234");
			Statement stmt = conn.createStatement(); {

				// 쿼리 실행
				stmt.executeUpdate(String.format("insert into (img) " + "values ('%s')" , file.getName()));

				// 메인 페이지로 돌아가기
				response.sendRedirect("list.jsp");
				return;
			 }

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//
		
		

		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String post_PW = request.getParameter("post_PW");
		HttpSession session = request.getSession();
		String img = null;

		int comments = 0;

		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		String time = simpleDateFormat.format(now);
		String nicName = (String) session.getAttribute("id");

		Dao dao = new Dao();
	
		dao.insert("INSERT INTO WRITE_FORM VALUES ('" + title + "','" + content + "', '" + post_PW + "', '"+ img +"')");

		dao.insert(
				"INSERT INTO LIST VALUES('" + title + "', '" + comments + "', '" + time + "', '" + nicName + "', NUM, '"+ content +"')");

		response.sendRedirect("list.jsp");

	}

}
