package DTO;

import lombok.Data;

@Data
public class PagingDTO {
	int page1 = 10;
	int page2 = 20;
	int next = 2;
	
}
