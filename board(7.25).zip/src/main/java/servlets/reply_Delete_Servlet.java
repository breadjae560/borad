package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.Dao;


@WebServlet("/reply_Delete_Servlet")
public class reply_Delete_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		Dao dao = new Dao();
		PrintWriter out = response.getWriter();

		String bno = request.getParameter("bno");
		String rno = request.getParameter("rno");
		
		dao.delete("DELETE FROM TBL_REPLY WHERE bno =" + bno + "AND rno = " + rno);
		
		response.sendRedirect("board.jsp");
	}

}
