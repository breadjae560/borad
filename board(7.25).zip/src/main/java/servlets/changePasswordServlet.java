package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.ProcessBuilder.Redirect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/changePasswordServlet")
public class changePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		HttpSession session = request.getSession();
		
		// 현재 세션에 로그인 되어있는 아이디 및 비밀번호를 얻어옴
		String curId = (String) session.getAttribute("id");
		String curPw = (String) session.getAttribute("pw");
		
		if(id.equals(curId) && pw.equals(curPw)) {
			response.sendRedirect("changePassword.jsp?pass=true");
		}else {
			response.sendRedirect("changePassword.jsp?pass=false");
		}
		
	}

}
