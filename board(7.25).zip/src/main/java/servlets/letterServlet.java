package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/letterServlet")
public class letterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date now = new Date();
		
		String id = request.getParameter("id");
		String dayCount = request.getParameter("dayCount");
		String nicname = request.getParameter("nicname");
		String welcome = request.getParameter("welcome");
		String letterCount = request.getParameter("letterCount");
		String time = simpleDateFormat.format(now);
		
		if(welcome.equals("T") || welcome.equals("t")) {
			// 첫 방문 유저
		}else if(welcome == "F" || welcome.equals("f")) {
			// 재방문 유저
			switch (dayCount) {
			case "1":
				out.print("<h1>1일차</h1>");
				break;
				
			case "2":
				out.print("<h1>2일차</h1>");
				break;	
				
			case "3":
				out.print("<h1>3일차</h1>");
				break;	
			default:
				out.print("over");
				break;
			}
			
			
		}
		
		
	}

}
