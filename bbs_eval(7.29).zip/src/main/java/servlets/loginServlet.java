package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.Dao;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		Dao dao = new Dao();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String log = null;
		String query = "select * from TBL_MEMBER";
		ResultSet rs = null;
		Statement stmt = null;
		Connection con = null;
		con = dao.DB_Con();

		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			
			while(rs.next()){
				
				if(id.equals(rs.getString(1)) && pw.equals(rs.getString(2))) {

					HttpSession session = request.getSession();
					System.out.println("ㅡㅡ유저 권한 로그인 시도(성공)ㅡㅡ");
					System.out.println("접속자 : " + id);
					log = getClientIP(request);
					System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡendㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
					session.setAttribute("id", id);
					session.setAttribute("pw", pw);
					session.setAttribute("name", rs.getString(3));
					session.setAttribute("email", rs.getString(4));
					session.setAttribute("permission", rs.getString(5));
					response.sendRedirect("mainPage.jsp");
					
				}else if(!id.equals(rs.getString(1)) && pw.equals(rs.getString(2))){
					out.print("<script>document.write('아이디 또는 비밀번호가 틀렸습니다.')</script>");
				}else if(id.equals(rs.getString(1)) && !pw.equals(rs.getString(2))) {
					out.print("<script>document.write('아이디 또는 비밀번호가 틀렸습니다.')</script>");
				}else if(!id.equals(rs.getString(1)) && !pw.equals(rs.getString(2))) {
					out.print("<script>document.write('아이디 또는 비밀번호가 틀렸습니다.')</script>");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private static final Logger logger = Logger.getLogger(loginServlet.class.getName());
	
	public static String getClientIP(HttpServletRequest request) {
	    String ip = request.getHeader("X-Forwarded-For");
	    if (ip == null) 
	        ip = request.getHeader("Proxy-Client-IP");	    
	    if (ip == null) 
	        ip = request.getHeader("WL-Proxy-Client-IP");    
	    if (ip == null) 
	        ip = request.getHeader("HTTP_CLIENT_IP");    
	    if (ip == null) 
	        ip = request.getHeader("HTTP_X_FORWARDED_FOR");  
	    if (ip == null) 
	        ip = request.getRemoteAddr();
	    logger.info("Result : IP Address : "+ip);
	    System.out.println("IP Address : "+ ip);

	    return ip;
	}	

}
