package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.Dao;

@WebServlet("/user_Posting_Update_Delete_Servlet")
public class user_Posting_Update_Delete_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();

		String update = request.getParameter("update");
		String delete = request.getParameter("delete");
		String bno = request.getParameter("bno");

		String pw = null;

		if (update != null) {
			response.sendRedirect("update.jsp?bno=" + bno);
		} else if (delete != null) {
			out.print("<script> " + pw + "= prompt('게시물 삭제을 위해 비밀번호를 입력하세요!')</script>");
			delete(pw, bno);
			response.sendRedirect("board.jsp");
		} else {
			System.out.println("update 와 delete 모두 null값이 들어왔음");
		}

	}


	void delete(String pw, String bno) {
		//String query = "SELETE POST_PW FROM WRITE_FORMDTO WHERE bno=" + bno;
		String pwCheck = null;
		Dao dao = new Dao();
		Connection con = dao.DB_Con();
		ResultSet rs = null;
		Statement stmt = null;

		/*try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				pwCheck = rs.getString(bno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}*/

		if (pw == pwCheck) {
			dao.delete("DELETE FROM TBL_REPLY WHERE BNO =" + bno);
			dao.delete("delete from TBL_BOARD where bno =" + bno);
			System.out.println("게시물 삭제 완료");

		} else {
			System.out.println("비밀번호 틀림");
		}

	}
	
}



