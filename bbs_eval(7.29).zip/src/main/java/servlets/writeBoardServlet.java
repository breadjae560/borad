package servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.Dao;


@WebServlet("/writeBoardServlet")
public class writeBoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		Dao dao = new Dao();
		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd");
		
		
		String catalogy = request.getParameter("catalogy"); 
		String writer = request.getParameter("name");
		String title = request.getParameter("title");
		String contents = request.getParameter("contents");
		String time = simpleDateFormat.format(now);
		String hits = request.getParameter("hits");
		
		switch(catalogy) { 
		
		case "board" : 
			String query = "INSERT INTO TBL_BOARD VALUES (SEQ_BNO.NEXTVAL, '"+ title +"', '"+ contents +"', '"+ writer +"', '"+time+"', "+ hits +")";
			dao.insert(query);
			response.sendRedirect("board.jsp");
			break;
		case "release" :	
			query = "INSERT INTO TBL_release VALUES (SEQ_RELEASE.NEXTVAL, '"+ title +"', '"+ contents +"', '"+ writer +"', '"+ time +"', "+ hits + ")";
			dao.insert(query);
			response.sendRedirect("releaseNote.jsp");
			break;
		case "QnA" :
			query = "INSERT INTO TBL_QNA VALUES (SEQ_QNO.NEXTVAL, '"+ title +"','"+contents+"','"+writer+"','"+time+"',"+hits+")";
			dao.insert(query);
			response.sendRedirect("myPage.jsp");
			break;
		default : 
			response.sendRedirect("mainPage.jsp");
			break;
		}


	}

}
