package DTO;

import lombok.Data;

@Data
public class BoardDTO {
	String bno;
	String title;
	String contents;
	String writer;
	String regdate;
	String hits;
}
