package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.Dao;


@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Dao dao = new Dao();
		
		String title = request.getParameter("title");
		String contents = request.getParameter("contents");
		String bno = request.getParameter("bno");
		System.out.println("update tbl_board set title = '"+ title +"' where bno =" + bno);
		System.out.println("update tbl_board set contents = '"+ contents +"' where bno =" + bno);
		
		dao.update("update tbl_board set title = '"+ title +"' where bno =" + bno);
		dao.update("update tbl_board set contents = '"+ contents +"' where bno =" + bno);
		
		response.sendRedirect("board.jsp");
		
	}

}
