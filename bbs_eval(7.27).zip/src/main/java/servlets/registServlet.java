package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.Dao;

@WebServlet("/registServlet")
public class registServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String pwcheck = request.getParameter("pwcheck");
		String name = request.getParameter("name");
		String email = request.getParameter("email");

		

		if (pw.equals(pwcheck)) {
			Dao dao = new Dao();
			String query = "select id from tbl_member";
			if(id.equals(query)) {
				query = "INSERT INTO TBL_MEMBER VALUES ('" + id + "', '" + pw + "', '" + name + "', '" + email + "')";
				dao.insert(query);
				response.sendRedirect("mainPage.jsp");				
			}else {
			out.print("<script>alert('이미 가입되어 있는 아이디입니다!')</script>");	
			}
		} else {
			out.print("<script>alert('비밀번호 중복체크 값이 틀렸습니다!')</script>");
		}

	}

}
