package DTO;

import lombok.Data;

@Data
public class MemberDTO {
	String id;
	String pw;
	String name;
	String email;
}
