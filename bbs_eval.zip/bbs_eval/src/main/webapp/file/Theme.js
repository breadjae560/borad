var theme = document.getElementsByClassName("theme");
//themeSave.addEventListener("click", themeSaves);

loadTheme();

function loadTheme() {
	if(theme == "aqua_blue") {
		theme.setAttribute('href', 'prj.css');
		themeSaves();
	}
	if(theme == "light_sky") {
		theme.setAttribute('href', 'prj.css');
		themeSaves();
	}
	if(theme == "half_sunset_glow") {
		theme.setAttribute('href', 'prj.css');
		themeSaves();
	}
	if(theme == "the_space_entrance") {
		theme.setAttribute('href', 'prj.css');
		themeSaves();
	}
	
	
}

function themeSaves() {
	sessionStorage.setItem("theme", loadTheme());
	localStorage.setItem('theme', loadTheme());
	sessionStorage.setItem("theme", theme );
	localStorage.setItem('theme', theme);
}





