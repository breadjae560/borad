const saveBtn2 = document.getElementById("save");
const fileInput = document.getElementById("file");
const canvas2 = document.querySelector("canvas");
const ctx2 = canvas2.getContext("2d");

canvas2.width = 500;
canvas2.height = 500;

saveBtn2.addEventListener("click", onSaveClick);
fileInput.addEventListener("change", onFileChange);


function onSaveClick() {
	
	const url2 = canvas2.toDataURL();
	const a = document.createElement("a")
	a.href = url2;
	a.download = "iconworld.png";
	a.click();
    
}

function onFileChange(event) {
	//window.location.href='https://www.coupang.com/';
	window.open('https://www.coupang.com/', '_blank');
	
	
	
    const file = event.target.files[0];
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.src = url;
    image.onload = function() {
        ctx2.drawImage(image, canvas2.width/2, canvas2.height/2);
        fileInput.value = null;
    }
}
