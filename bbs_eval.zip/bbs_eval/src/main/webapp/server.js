import { createServer } from 'http';
import { readFileSync } from 'fs';

var app = createServer(function(request,response){
    var url = request.url;
    if(request.url == '/'){
      url = '/mainPage.jsp';
    }
    
    
    
    
    if(request.url == '/favicon.ico'){
      response.writeHead(404);
		response.end();
		return;
    }
    response.writeHead(200);
    response.end(readFileSync(__dirname + url));
 
});
app.listen(5000);