package com.prj.domain;

import lombok.Data;

@Data
public class MemberDTO {
	String id;
	String pw;
	String name;
	String email;
	String permission;

}
