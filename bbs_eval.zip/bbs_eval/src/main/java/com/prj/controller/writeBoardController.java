package com.prj.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.prj.repository.Dao;


@WebServlet("/writeBoardController")
public class writeBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		Dao dao = new Dao();
		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		String time = simpleDateFormat.format(now);
		
		
		String catalogy = request.getParameter("catalogy"); 
		String writer = request.getParameter("name");
		String title = request.getParameter("title");
		String contents = request.getParameter("contents");
		String bno = request.getParameter("bno");
		String hits = "1";
		String boardpassword = request.getParameter("boardpassword");
		
		
		
		PrintWriter out = response.getWriter();
		String pw = null;
		
		
		
		switch(catalogy) { 
			
		
			// ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ 게시판 리스트 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
			//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
		
		
		case "board" : // 게시글 작성
			String query = "INSERT INTO TBL_BOARD VALUES (SEQ_BNO.NEXTVAL, '"+ title +"', '"+ contents +"', '"+ writer +"', "+ time +", "+ hits +", "+ boardpassword + ")";
			dao.insert(query);
			response.sendRedirect("board.jsp");
			break;
		case "release" : // (관리자)릴리즈 노트 작성
			query = "INSERT INTO TBL_release VALUES (SEQ_RELEASE.NEXTVAL, '"+ title +"', '"+ contents +"', '"+ writer +"', "+ time +", "+ hits + ")";
			dao.insert(query);
			response.sendRedirect("releaseNote.jsp");
			break;
		case "QnA" : // QnA 작성
			query = "INSERT INTO TBL_QNA VALUES (SEQ_QNO.NEXTVAL, '"+ title +"','"+contents+"','"+writer+"',"+ time +","+hits+")";
			dao.insert(query);
			response.sendRedirect("myPage.jsp");
			break;
			
			// ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ 작성글 수정 폼 / 수정 /삭제 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
			//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
			
			
		case "board_update" : // 작성자가 작성글 수정 폼에서 제출할때 쓰이는 카탈로지.	
			
			dao.update("update tbl_board set title = '"+ title +"' where bno =" + bno);
			dao.update("update tbl_board set contents = '"+ contents +"' where bno =" + bno);
			response.sendRedirect("board.jsp");
			break;			
			
			
		case "update_btn" : // 작성자가 작성글에서 "수정"을 제출했을때 입력되는 카탈로지
			response.sendRedirect("update.jsp?bno=" + bno);
			break;
			
		case "delete_btn" : // 작성자가 작성글에서 "삭제"를 제출했을때 입력되는 카탈로지
			out.print("<script> " + pw + "= prompt('게시물 삭제을 위해 비밀번호를 입력하세요!')</script>");
			delete(pw, bno);
			response.sendRedirect("board.jsp");
			break;

		default : 
			response.sendRedirect("mainPage.jsp");
			break;
		}

	}
	
	void delete(String pw, String bno) {
		//String query = "SELETE POST_PW FROM WRITE_FORMDTO WHERE bno=" + bno;
		String pwCheck = null;
		Dao dao = new Dao();
		Connection con = dao.DB_Con();
		ResultSet rs = null;
		Statement stmt = null;

		/*try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				pwCheck = rs.getString(bno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}*/

		if (pw == pwCheck) {
			dao.delete("DELETE FROM TBL_REPLY WHERE BNO =" + bno);
			dao.delete("delete from TBL_BOARD where bno =" + bno);
			System.out.println("게시물 삭제 완료");

		} else {
			System.out.println("비밀번호 틀림");
		}

	}

}
