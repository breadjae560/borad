var theme = document.getElementsByClassName("theme")

loadTheme();

function loadTheme() {
	if(theme == "aqua_blue") {
		theme.setAttribute('href', '/css/cssfile.css');
		
	}
	if(theme == "light_sky") {
		theme.setAttribute('href', '/css/cssfile.css');
		
	}
	if(theme == "half_sunset_glow") {
		theme.setAttribute('href', '/css/cssfile.css');
		
	}
	if(theme == "the_space_entrance") {
		theme.setAttribute('href', '/css/cssfile.css');
		
	}
	
	localStorage.setItem('theme', theme);
	
	
	
}