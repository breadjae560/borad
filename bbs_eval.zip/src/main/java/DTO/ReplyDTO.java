package DTO;

import lombok.Data;

@Data
public class ReplyDTO {
	String rno;
	String comments;
	String writer;
	String regdate;
	String bno;
}
