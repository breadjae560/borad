package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DTO.PagingDTO;


@WebServlet("/pagingServlet")
public class pagingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		PagingDTO p = new PagingDTO(); 
		
		String page1_temp = request.getParameter("page1");
		String page2_temp = request.getParameter("page2");
		String nextPage_temp = request.getParameter("next");
		
		int page1 = Integer.parseInt(page1_temp);
		int page2 = Integer.parseInt(page2_temp);
		int next = Integer.parseInt(nextPage_temp);
				
		System.out.println("넘어온 값: page1 =" + page1);
		System.out.println("넘어온 값: page2 =" + page2);
		System.out.println("넘어온 값: next =" + next);
		
		page1 += 10;
		page2 += 10;
		next += 1;
		
		p.setPage1(page1);
		p.setPage2(page2);
		p.setNext(next);
		
		
		response.sendRedirect("board.jsp?page1=" + page1 + "&page2=" + page2 + "&next=" + next);
		
		
		
	}

}
