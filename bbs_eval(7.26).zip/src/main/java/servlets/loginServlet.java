package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.Dao;
import DTO.MemberDTO;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		/*
		Dao dao = new Dao();
		Connection con = dao.DB_Con();
		MemberDTO mb = new MemberDTO();
		Statement stmt = null;
		ResultSet rs = null;
		String query = "SELECT * FROM TBL_MEMBER";
		dao.select(query);
		
		try {
			
			stmt = con.createStatement();
			
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				
				mb.setId(rs.getString(1));
				mb.setPw(rs.getString(2));
				mb.getId();
				mb.getPw();	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
		String idCheck = "admin";
		String pwCheck = "1234";
		
		
		if (id.equals(idCheck) && pw.equals(pwCheck)) {
			HttpSession session = request.getSession();
			out.print("<script>alert('로그인 성공')</script>");
			System.out.println("접속자 : " + id);
			session.setAttribute("id", id);
			session.setAttribute("pw", pw);
			Dao dao = new Dao();
			response.sendRedirect("mainPage.jsp");
		}
	}

}
