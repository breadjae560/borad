package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {
	
	@RequestMapping("/changePassword")
	public String changePassword() {

		
		return "changePassword";
	}
	
	@RequestMapping("/client")
	public String client() {

		
		return "client";
	}
	
	@RequestMapping("/myPage")
	public String myPage() {

		
		return "myPage";
	}
}
