package com.example.repository;

import java.sql.Connection;
import java.util.ArrayList;

import com.example.domain.MemberDTO;
import com.example.domain.ReplyDTO;

public interface IRepository {
	public Connection DB_Con();
	public ArrayList<MemberDTO> select(String query);
	public ArrayList<ReplyDTO> select_reply(String query);
	public void insert(String query);
	public void update(String query);
	public void delete(String query);
}
