package com.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import com.DTO.*;

public class Dao {
	Connection con = null;

	public Connection DB_Con() {
		String url = "jdbc:oracle:thin:@localhost:1521/xe";
		String uid = "system";
		String upw = "1234";

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(url, uid, upw);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public ArrayList<MemberDTO> select(String query) {
		con = DB_Con();
		ResultSet rs = null;
		MemberDTO iiv = new MemberDTO();
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

		try {

			Statement stmt = con.createStatement();

			rs = stmt.executeQuery(query);

			while (rs.next()) {
				
				iiv.setId(rs.getString("id"));
				iiv.setPw(rs.getString("pw"));
				list.add(iiv);
				break;
				
			}

			for (MemberDTO m : list) {

				System.out.println(m.getId());
				System.out.println(m.getPw());

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return list;

	}

	public void insert(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void update(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void delete(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
