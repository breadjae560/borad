package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.Dao;

@WebServlet("/registServlet")
public class registServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String nicName = request.getParameter("nicName");
		String email = request.getParameter("email");
		String tel = request.getParameter("tel");

		Dao dao = new Dao();

		dao.insert("INSERT INTO GREEN01.MEMBER VALUES ('" + id + "','" + pw + "','" + nicName + "', '" + email + "', '" + tel + "')");
		out.print("<script>alert('회원가입 완료!')</script>");

		try {
			Thread.sleep(1000);
			response.sendRedirect("main.jsp");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

}
