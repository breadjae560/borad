package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.Dao;

@WebServlet("/user_Posting_Update_Delete_Servlet")
public class user_Posting_Update_Delete_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");

		PrintWriter out = response.getWriter();

		String update = request.getParameter("update");
		String delete = request.getParameter("delete");
		String num = request.getParameter("num");

		String pw = null;

		if (update != null) {
			out.print("<script> " + pw + "= prompt('게시물 수정을 위해 비밀번호를 입력하세요!')</script>");
			update(pw);
			response.sendRedirect("list.jsp");
		} else if (delete != null) {
			out.print("<script> " + pw + "= prompt('게시물 삭제을 위해 비밀번호를 입력하세요!')</script>");
			delete(pw, num);
			response.sendRedirect("list.jsp");
		} else {
			System.out.println("update 와 delete 모두 null값이 들어왔음");
		}

	}

	void update(String pw) {
		// 작성자가 적은 PW
		String pwCheck = "1234";
		Dao dao = new Dao();
		
		
		
		
		
		
		if (pw == pwCheck) {

		}
	}

	void delete(String pw, String num) {
		String query = "SELETE POST_PW FROM WRITE_FORMDTO WHERE NUM=" + num;
		String pwCheck = null;
		Dao dao = new Dao();
		Connection con = dao.DB_Con();
		ResultSet rs = null;
		Statement stmt = null;

		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				pwCheck = rs.getString(num);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (pw == pwCheck) {
			dao.delete("delete from list where num =" + num);
			System.out.println("게시물 삭제 완료");

		} else {
			System.out.println("비밀번호 틀림");
		}

	}

}
