package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		//DB Zone
		//Dao dao = new Dao();

		String idCheck = "admin";
		//request.setAttribute(idCheck, dao.select("SELECT ID FROM MEMBER_2"));
		String pwCheck = "1234";
		//request.setAttribute(pwCheck, dao.select("SELECT PW FROM MEMBER_2"));
		
		if (id.equals(idCheck) && pw.equals(pwCheck)) {
			HttpSession session = request.getSession();
			out.print("<script>alert('로그인 성공')</script>");
			System.out.println("접속자 : " + id);
			session.setAttribute("id", id);
			session.setAttribute("pw", pw);
			response.sendRedirect("main.jsp");
		}
		
	}

}
