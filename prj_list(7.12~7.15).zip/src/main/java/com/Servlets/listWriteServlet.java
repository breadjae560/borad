package com.Servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.Dao;

@WebServlet("/listWriteServlet")
public class listWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");

		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String post_PW = request.getParameter("post_PW");
		HttpSession session = request.getSession();

		int comments = 0;

		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		String time = simpleDateFormat.format(now);
		String nicName = (String) session.getAttribute("id");

		Dao dao = new Dao();

		dao.insert("INSERT INTO WRITE_FORM VALUES ('" + title + "','" + content + "', '" + post_PW + "')");

		dao.insert(
				"INSERT INTO LIST VALUES('" + title + "', '" + comments + "', '" + time + "', '" + nicName + "', NUM, '"+ content +"')");

		response.sendRedirect("list.jsp");

	}

}
