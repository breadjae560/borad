package com.Servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.Dao;

@WebServlet("/listWriteServlet")
public class listWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
	    int comment = 0;
	    Date now = new Date();
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	    
	    String time = simpleDateFormat.format(now);
		
		Dao dao = new Dao();
		
		dao.insert("INSERT INTO WRITE_FORM VALUES ('"+ title +"','"+ content +"')");
		dao.insert("INSERT INTO list VALUES('"+ title +"', '"+ comment +"', '"+ time +"' )");
				
		response.sendRedirect("list.jsp");
	
	}

}
