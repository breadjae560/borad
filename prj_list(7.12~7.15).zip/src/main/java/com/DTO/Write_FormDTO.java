package com.DTO;

public class Write_FormDTO {
	String title;
	String content;
	String post_PW;
}
