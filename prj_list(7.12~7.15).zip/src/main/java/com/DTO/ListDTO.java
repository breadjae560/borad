package com.DTO;

import lombok.Data;

@Data
public class ListDTO {
	String title;
	String comments;
	String time;
	String content;
}
