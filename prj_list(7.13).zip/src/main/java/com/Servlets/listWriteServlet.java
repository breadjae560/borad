package com.Servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.Dao;

@WebServlet("/listWriteServlet")
public class listWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");

		String title = request.getParameter("title");
		String content = request.getParameter("content");
		HttpSession session = request.getSession();

		int comments = 0;
		
		//String seq = "SEQ_LIST_NUMBER.NEXTVAL";
		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		String time = simpleDateFormat.format(now);
		String nicName = (String)session.getAttribute("id");

		Dao dao = new Dao();
		String query = "INSERT INTO GREEN01.LIST VALUES('" + title + "', '" + comments + "', '" + time + "', '" + nicName
				+ "', 20)";
		
		System.out.println(query);
		dao.insert("INSERT INTO GREEN01.WRITE_FORM VALUES ('" + title + "','" + content + "')");
		
		dao.insert("INSERT INTO GREEN01.LIST VALUES('" + title + "', '" + comments + "', '" + time + "', '" + nicName
				+ "', SEQ_LIST_NUMBER.NEXTVAL)");

		response.sendRedirect("list.jsp");

	}

}
