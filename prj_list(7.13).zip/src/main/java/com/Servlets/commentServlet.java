package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.Dao;

@WebServlet("/commentServlet")
public class commentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();

		Date now = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String post_Num = request.getParameter("num");
		String time = simpleDateFormat.format(now);
		String nicName = (String)session.getAttribute("id");
		String post_Comment = "댓글댓글댓글";

		Dao dao = new Dao();

		dao.insert("INSERT INTO USER_COMMENT VALUES ("+ post_Num +",SEQ_USER_COMMENT.NEXTVAL, '" + nicName + "', '" + post_Comment
				+ "', '" + time + "')");

		response.sendRedirect("user_Posting.jsp?num=" + post_Num);

	}

}
