package com.prj.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.prj.repository.Dao;

@WebServlet("/replyController")
public class replyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		Date now = new Date();
		Dao dao = new Dao();

		String time = simpleDateFormat.format(now);
		String name = request.getParameter("name");
		String comments = request.getParameter("comments");
		String bno = request.getParameter("bno");

		String reply = request.getParameter("reply");

		switch (reply) {
		case "create":
			String query = "INSERT INTO TBL_REPLY VALUES (SEQ_RNO.NEXTVAL, '" + comments + "','" + name + "', '" + time
					+ "', " + bno + ")";
			dao.insert(query);
			response.sendRedirect("board.jsp");
			break;

		case "delete":
			bno = request.getParameter("bno");
			String rno = request.getParameter("rno");
			dao.delete("DELETE FROM TBL_REPLY WHERE bno =" + bno + "AND rno = " + rno);
			response.sendRedirect("board.jsp");
			break;

		default:
			break;
		}

	}

}
