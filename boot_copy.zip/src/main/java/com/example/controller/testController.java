package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class testController {
	
	@RequestMapping("/test")
	public String test() {
		
		//log.info("...test 메소드");
		System.out.println(".test 메소드");
	
		
		return "index2";
	}
	
	
	@RequestMapping("/mainPage")
	public String main() {
		
		//log.info("...mainPage 메소드");
		System.out.println(".mainPage 메소드");
		
		return "mainPage";
	}

	
}
