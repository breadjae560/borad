package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WriteController {

	@RequestMapping("/update")
	public String update() {
		
		return "update";
	}
	
	@RequestMapping("/writeBoard")
	public String writeBoard() {
		
		return "writeBoard";
	}
	
	@RequestMapping("/writeQnA")
	public String writeQnA() {
		
		return "writeQnA";
	}
	
	@RequestMapping("/writeReleaseNote")
	public String writeReleaseNote() {
		
		return "writeReleaseNote";
	}
	
	
	@RequestMapping("user_Posting")
	public String user_Posting() {
		
		return "user_Posting";
	}
	
	
	
	
	
}
