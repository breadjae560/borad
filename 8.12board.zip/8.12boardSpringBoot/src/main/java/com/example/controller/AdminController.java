package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// TODO : requestMapping 부분에 post, get 안나눴으니 수정할것.

@Controller
public class AdminController {
	@RequestMapping("/admin")
	public String admin() {
		
		return "admin";
	}
}
