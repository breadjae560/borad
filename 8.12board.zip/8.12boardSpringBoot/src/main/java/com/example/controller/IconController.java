package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IconController {

	@RequestMapping("icons")
	public String icons() {
		return "icons";
	}
	
	@RequestMapping("icons_Detail")
	public String icons_Detail() {
		return "icons_Detail";
	}
	
}
