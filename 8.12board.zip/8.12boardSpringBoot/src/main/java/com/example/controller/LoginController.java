package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	@PostMapping("/loginPage")
	public String loginPage() {
		
		
		return "loginPage";
	}
	
	@RequestMapping("/logoutPage")
	public String logoutPage() {
		
		
		return "logoutPage";
	}
	
	
	
}
